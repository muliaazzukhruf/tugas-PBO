print ("MENGHITUNG LUAS SEGITIGA")
a = float (input("Masukkan panjang alas = "))
t = float (input("Masukkan panjang tinggi = "))

luasSegitiga = 0.5*a*t

print ("Luas Segitiga adalah ", luasSegitiga)