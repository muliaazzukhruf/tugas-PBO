print ("MENGHITUNG VOLUME BALOK")
p = float (input("Masukkan panjang sisi = "))
l = float (input("Masukkan lebar sisi = "))
t = float (input("Masukkan tinggi sisi = "))

volumeBalok = p*l*t

print ("Volume balok  adalah ", volumeBalok)