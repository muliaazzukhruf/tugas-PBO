print ("JAJAR GENJANG")
n = int (input("masukkan n: "))
i = 1
a = n
while (i<=n):
    print (" "*(n-1), "*" * a)
    n = n-1